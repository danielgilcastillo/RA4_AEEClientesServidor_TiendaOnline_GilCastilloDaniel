<?php
require_once("clases.php");

$key = "CLAVEDEFIRMA";

function generarTokenJWT($usuario)
{
    global $key;

    $header = json_encode([
        'alg' => 'HS256', 
        'typ' => 'JWT'
    ]);
    $payload = json_encode([
        'sub' => $usuario['id'],
        'name' => $usuario['username'],
        'iat' => time(),
        'exp' => time() + 3600
    ]);

    $header_base64 = base64UrlEncode($header);
    $payload_base64 = base64UrlEncode($payload);

    // Generar la firma usando Base64Url seguro
    $signature = base64UrlEncode(hash_hmac('sha256', "$header_base64.$payload_base64", $key, true));

    return "$header_base64.$payload_base64.$signature";
}

function verificarTokenJWT($token)
{
    global $key;

    $partes = explode('.', $token);
    if (count($partes) !== 3) {
        responderYSalir(false, "Error en cabecera");
    }

    $header_base64 = $partes[0];
    $payload_base64 = $partes[1];
    $firma_enviada = $partes[2];

    // Calcular la firma con Base64Url seguro
    $firma_calculada = base64UrlEncode(hash_hmac('sha256', "$header_base64.$payload_base64", $key, true));


    // Comparar firmas
    if ($firma_enviada !== $firma_calculada) {
        responderYSalir(false, "La firma no coincide");
    }

    // Decodificar y validar el payload
    $payload = json_decode(base64UrlDecode($payload_base64), true);
    if ($payload['exp'] < time()) {
        responderYSalir(false, "El token ha expirado");
    }

    // // Token válido, devolvemos el payload
    // return $payload;

    // Recoger el cuerpo de la solicitud (JSON en bruto)
    $bodyrecibidoenjon = file_get_contents('php://input');

    // Decodificar el JSON en un array asociativo de PHP, y devolverlo
    $bodyrecibidoenarray = json_decode($bodyrecibidoenjon, true);
    return $bodyrecibidoenarray;
}


function responderYSalir($exito, $respuesta)
{
    echo json_encode(['exito' => $exito, 'respuesta' => $respuesta]);
    exit;
}

function base64UrlEncode($data)
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64UrlDecode($data)
{
    return base64_decode(strtr($data, '-_', '+/'));
}


function leerCategorias()
{
    // Leer el JSON de categorías
    $categoriasJson = file_get_contents('categorias.json');
    $categoriasArray = json_decode($categoriasJson, true);

    // Crear una colección de objetos de la clase Categoria
    $categorias = [];
    foreach ($categoriasArray as $categoriaData) {
        $categorias[] = new Categoria($categoriaData['idCategoria'], $categoriaData['nombre']);
    }
    // devuelve la coleccion
    return $categorias;
}


function leerProductos()
{
    // Leer el JSON de productos
    $productosJson = file_get_contents('productos.json');
    $productosArray = json_decode($productosJson, true);

    // Crear una colección de objetos de la clase Producto
    $productos = [];
    foreach ($productosArray as $categoriaId => $productosDeCategoria) {
        foreach ($productosDeCategoria as $productoData) {
            $productos[] = new Producto(
                $productoData['idProducto'],
                $productoData['nombre'],
                $productoData['precio'],
                $productoData['destacado'],
                $productoData['id_categoria']
            );
        }
    }
    return $productos;
}


