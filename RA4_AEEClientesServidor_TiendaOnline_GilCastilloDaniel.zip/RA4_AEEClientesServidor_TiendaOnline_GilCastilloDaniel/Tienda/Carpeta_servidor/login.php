<?php
require_once('utilidades.php');

header('Content-Type: application/json; charset=UTF-8');

// Recoger el cuerpo de la solicitud (JSON en bruto)
$jsonrecibido = file_get_contents('php://input');

// Decodificar el JSON en un array asociativo de PHP
$arraydedatosrecibidos = json_decode($jsonrecibido, true);

// Acceder a los valores enviados en el JSON
$nombre = $arraydedatosrecibidos['nombre'] ?? null;
$password = $arraydedatosrecibidos['password'] ?? null;

//leemos el fichero usuarios.json
$usuariosJson = file_get_contents('usuarios.json');

// Decodificar el JSON en un array asociativo
$usuariosArray = json_decode($usuariosJson, true);

// COMPROBAMOS SI EL USUARIO Y LA PASSWORD QUE NOS ENVIAN
// COINDICE CON ALGUN DE LAS QUE EL SERVIDOR TIENE
$usuarioencontrado = null;
foreach ($usuariosArray['usuarios'] as $usuario) {
    // Realiza validación 
    if ($nombre === $usuario['username'] && $password === $usuario['password'] ) {
        $usuarioencontrado = $usuario;
    }
}

// VEMOS SI EL USUARIO SE HA ENCONTRADO O NO
if ($usuarioencontrado == null) {
    $arrayRespuesta = ['exito' => false, 'nombre' => "Datos incorrectos"];
    // convierto el array en un JSON
    $arrayenJSON = json_encode($arrayRespuesta);
    // escribo y envio la respuesta
    http_response_code(403); // Código HTTP numero 403, de error
    echo $arrayenJSON;
    exit();
} else {
    // el uduario y passrowrd son correctas, seguimos:
    //leemos el fichero tienda.json
    $tiendaJson = file_get_contents('tienda.json');
    $tiendaleidadejson = json_decode($tiendaJson, true);

    // GENERAMOS EL TOKEN
    $token = generarTokenJWT($usuarioencontrado);
    $token = utf8_encode($token);

    // hemos de enviar al cliente la tienda que hemos leido y el token generado,
    // mete ambas cosas en arrayRespuesta
    $arrayRespuesta = ['exito' => true, 'TOKEN' => $token, 'tienda' => $tiendaleidadejson];
    // convierto el array en un JSON
    $arrayenJSON = json_encode($arrayRespuesta);
    http_response_code(200); // Código HTTP de que va todo ok, un 200
    // escribo y envio la respuesta
    echo $arrayenJSON;
    exit();
}

