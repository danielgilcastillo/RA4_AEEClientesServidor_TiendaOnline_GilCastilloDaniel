<?php

require_once('utilidades.php');
header('Content-Type: application/json; charset=UTF-8');

$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';


if (preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    // SACAMOS EL TOKEN QUE NOS ENVIAN Y LO GUARDAMOS
    $token = $matches[1];
    // COMPROBAMOS QUE EL TOKEN ES CORRECTO
    $arraycarrito = verificarTokenJWT($token);
} else {
    http_response_code(401);
    echo json_encode(['exito' => false, 'respuesta' => 'Error. Token no proporcionado']);
}

// COMPROBAR QUE LOS PRECIOS DE LOS PRODUCTOS DEL CARRITO COINCIDEN CON LOS ORIGINALES Y NO SE HAN CAMBIADO
// leemos fichero de precios originales
$tiendaJson = file_get_contents('tienda.json');
$arraytienda = json_decode($tiendaJson, true);
$textoquesedevuelve = "";

// comparamos precios originales y recibidos
foreach ($arraycarrito as $cadaproductodelcarrito) {
    foreach ($arraytienda['productos'] as $cadaproductodelatienda) {
        if ($cadaproductodelatienda['idProducto'] == $cadaproductodelcarrito['idProducto']) {
            if ($cadaproductodelatienda['precio'] != $cadaproductodelcarrito['precio']) {
                // EL PRECIO HA SIDO MANIPULADO EN EL CLIENTE, DEVOLVEMOS ERROR
                $textoquesedevuelve = "ERROR : EL precio del producto " . $cadaproductodelatienda['nombre'] . " ha sido modificado";
                responderYSalir(false, $textoquesedevuelve);
            }
        }
    }
}

// si hemos llegado aqui, es que no hay errores
responderYSalir(true, "PAGO REALIZADO CORRECTAMENTE");
