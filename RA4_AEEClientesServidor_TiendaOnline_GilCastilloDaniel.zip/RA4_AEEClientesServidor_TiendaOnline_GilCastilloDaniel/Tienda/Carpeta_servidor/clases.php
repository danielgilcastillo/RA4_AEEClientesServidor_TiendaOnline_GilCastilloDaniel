<?php

class Categoria {
    public $idCategoria;
    public $nombre;

    public function __construct($idCategoria, $nombre) {
        $this->idCategoria = $idCategoria;
        $this->nombre = $nombre;
    }
}


class Producto {
    public $idProducto;
    public $nombre;
    public $precio;
    public $destacado;
    public $idCategoria;

    public function __construct($idProducto, $nombre, $precio, $destacado, $idCategoria) {
        $this->idProducto = $idProducto;
        $this->nombre = $nombre;
        $this->precio = $precio;
        $this->destacado = $destacado;
        $this->idCategoria = $idCategoria;
    }
}




