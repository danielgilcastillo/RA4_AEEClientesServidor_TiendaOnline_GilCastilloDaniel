<?php

// A ESTE PROGRAMA SE LLAMA DESDE EL INICIO DE CUALQUIER PAGINA DE LA WEB
// PARA COMPROBAR QUE EL TOKEN QUE TIENEN ES CORRECTO Y SE HA ENTRADO POR EL LOGIN
// SI EL TOKEN QUE SE ENVIA ES INVALIDO, ESTE PROGRAMA LO DETECTA
header("Content-Type: application/json");
require_once('utilidades.php');

$headers = getallheaders();
// COGEMOS EL TOKEN QUE SE RECIBE DEL CLIENTE
$tokenrecibidodesdejavascript = $headers['Authorization'] ?? '';

if (!$tokenrecibidodesdejavascript ) {
    // SI el token no se ha encontrado en la cabecera, luego no se ha enviado... 
    // ponemos como codigo de respuesta un 403 (error) y nos piramos
    http_response_code(403); // Código HTTP de error
    echo json_encode(["error" => "Token inválido"]); // Mensaje adicional
    exit;
}

if (!verificarTokenJWT($tokenrecibidodesdejavascript)) {
    // el token se ha recibido, pero no se ha podido validar, viene distinto del que se 
    // tiene en el servidor, asi que ponemos como codigo de respuesta un 403 (error) y nos piramos
    http_response_code(403); // Código HTTP de error
    echo json_encode(["error" => "Token inválido"]); // Mensaje adicional
    exit;
}

// SI SE LLEGA AQUI, El token existe, y es valido, asi que 
// ponemos como codigo de respuesta un 200 (ok) y nos piramos
http_response_code(200); // Código HTTP de éxito
echo json_encode(["mensaje" => "Token válido"]);
exit;
