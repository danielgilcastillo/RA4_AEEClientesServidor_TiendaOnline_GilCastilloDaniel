window.onload = inicio

localStorage.clear();

function inicio() {

    card = ` <div class="card">
                  <div class="card-body">
                     <h5 class="card-title">DESCONEXION</h5>   
                     <p class="card-text text-primary">Se he desconectado del sistema. Necesita volver a login para acceder nuevamente</p>     
                     <a href="pagina_login.html" class="btn btn-primary">Volver a login</a>
                  </div>
             </div>`
    document.getElementById("areadecolocaciondeestapagina").innerHTML = card

}
