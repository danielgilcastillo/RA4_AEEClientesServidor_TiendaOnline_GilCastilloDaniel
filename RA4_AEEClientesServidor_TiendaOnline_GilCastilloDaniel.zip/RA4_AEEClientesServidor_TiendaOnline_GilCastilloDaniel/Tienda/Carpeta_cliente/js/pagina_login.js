window.onload = inicio

localStorage.clear();

carpeta_proyecto = "http://localhost/TIENDA/"

function inicio() {

    var elboton = document.getElementById("boton")

    // ENVIO DE LOGIN
    elboton.addEventListener("click", async (evento) => {

        // Prevenir el envío estándar del formulario
        evento.preventDefault()

        const cajasdelformulario = evento.target.closest('form');
        const datosDelFormulario = new FormData(cajasdelformulario);

        // creo un objeto literal
        const arraycondatosdeenvio = {
            nombre: datosDelFormulario.get('nombre'),
            password: datosDelFormulario.get('password')
        }

        const response = await fetch(carpeta_proyecto + 'Carpeta_servidor/LOGIN.PHP', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8'
            },
            // convertirmos el objeo literal a un JSON-string para enviarlo 
            body: JSON.stringify(arraycondatosdeenvio)
        });


        // ============================
        if (response.ok) {
            const arrayrespuesta = await response.json(); // leemos el JSON que envia desde PHP
            // almacenar el token en el localstorage
            guardarLocalstorage("TOKEN", arrayrespuesta['TOKEN'])

            // almacenar la tienda en el localstorage
            guardarLocalstorage("TIENDA", arrayrespuesta['tienda'])

            // almacenar carrito vacio en el localstorage
            arraycarrito = []
            guardarLocalstorage("CARRITO", arraycarrito)

            // almacenar elementos recientes (vacio) en el localstorage
            arrayvistos = []
            guardarLocalstorage("VISTOS", arrayvistos)

            // llamar a dashboard.html
            window.location.href = 'pagina_catalogo.html?opcion=todos';

        } else {
            alert('Usuario o contraseña incorrectos');
        }
    });
}


// guarda un objeto en localstorage, pero ha de ser un STRING, 
// convertir un objeto en string con JSON.stringify( objeto ) 
function guardarLocalstorage(nombre, unobjeto) {
    cadena = JSON.stringify(unobjeto),
        localStorage.setItem(nombre, cadena)
}

// devuelve el contenido de localstotage como un STRING, 
// se convierte un string en un objeto con JSON.parse( stringdado  )
function leerDeLocalstorage(nombre) {
    return JSON.parse(localStorage.getItem(nombre))
}
