
    // ---------- enviar token a servidor y ver si es valido, si no, volvemos a login.html
    enviarToken()
    
    async function enviarToken(){

        tokenrecuperadodestorage = leerDeLocalstorage("TOKEN")
  
         if( ! tokenrecuperadodestorage ){
            // el token no existe, ni siquiera se ha pasado antes por login y se ha pedido al servidor, 
            // asi que nos piramos al login.html
            alert("Debe autenticarse para acceder al contenido de la web")
            window.location.href  ="pagina_login.html"
         } 

    
         // llegados aqui, es que hay token, 
         // pero necesitamos pedir al servidor que valide la integridad del token que tenemos 

         carpeta_proyecto = "http://localhost/Tienda/"
         const response = await fetch(carpeta_proyecto + 'Carpeta_servidor/responder_si_token_vale.PHP', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${tokenrecuperadodestorage}` },
            // convertirmos el objeo literal a un JSON para enviarlo 
            body: JSON.stringify("")
        });

        // ================ respuesta de servidor  ==============
        if (response.status == 200) {  // es lo mismo que response.ok, es que hemos recibido un codigo de respuesta 200

            // no hacemos nada

        } else {
            // asi que nos piramos al login.html
            window.location.href  ="pagina_login.html"
        }

    }

    
    // devuelve el contenido de localstotage como un STRING, 
    // se convierte un string en un objeto con JSON.parse( stringdado  )
    function leerDeLocalstorage(nombre) {
        cadena = localStorage.getItem(nombre)
        if(cadena==''){
            return null
        }
        return JSON.parse(cadena)
    }
