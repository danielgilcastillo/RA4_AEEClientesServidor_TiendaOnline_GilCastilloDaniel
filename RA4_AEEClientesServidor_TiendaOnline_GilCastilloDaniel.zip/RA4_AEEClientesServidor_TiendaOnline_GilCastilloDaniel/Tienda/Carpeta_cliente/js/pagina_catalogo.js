
// ---------- enviar token a servidor y ver si es valido, si no, volvemos a login.html
enviarToken()
// CODIGO JAVASCRIPT IGUAL PARA TODAS LAS PAGINAS 
window.onload = inicio
function inicio() {

    // Cargar contenido de cabecera.html
    fetch('componente_cabecera.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('contenedor-cabecera').innerHTML = html;
        })
    //Cargar contenido de cabecera.html
    fetch('componente_pie.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('contenedor-pie').innerHTML = html;
        })

    area = document.getElementById("pagina")

    tiendacomoobjeto = leerDeLocalstorage("TIENDA")

    // Obtener los parámetros de la URL
    const queryString = window.location.search;
    // Crear un objeto con los parámetros usando URLSearchParams
    const urlParams = new URLSearchParams(queryString);
    // Leer los valores de los parámetros
    const opcion = urlParams.get('opcion');
    const categoria = urlParams.get('categoria');

    if (opcion == "todos") {
        textotitulo = `<div class="col-md-12 text-center">
                              <h1>CATALOGO</h1>
                           </div>`

        coleccion_recorrida = tiendacomoobjeto.productos
    } else if (categoria == "1") {  // ELECTRONICA
        textotitulo = `<div class="col-md-12 text-center">
                              <h1>CATALOGO PARA CATEGORIA: ELECTRONICA</h1>
                           </div>`

        coleccion_recorrida = filtrarPorCategoria("1")

    } else if (categoria == "2") {
        textotitulo = `<div class="col-md-12 text-center">
                              <h1>CATALOGO PARA CATEGORIA: JUGUETES </h1>
                           </div>`

        coleccion_recorrida = filtrarPorCategoria("2")

    } else if (categoria == "3") {
        textotitulo = `<div class="col-md-12 text-center">
                              <h1>CATALOGO PARA CATEGORIA: ROPA </h1>
                           </div>`
        coleccion_recorrida = filtrarPorCategoria("3")

    } else if (opcion == "destacados") {
        textotitulo = `<div class="col-md-12 text-center">
                              <h1>MIS PRODUCTOS DESTACADOS </h1>
                           </div>`

        coleccion_recorrida = filtrarPorDestacados()
    } else {
        textotitulo = `<div class="col-md-12 text-center">
                              <h1>VISTOS RECIENTEMENTE </h1>
                           </div>`

        arrayvistos = leerDeLocalstorage("VISTOS")
        coleccion_recorrida = arrayvistos
    }

    document.getElementById("titulopagina").innerHTML = textotitulo
    area = document.getElementById("pagina")

    pintar(opcion, coleccion_recorrida)

}



function pintar(opcion, coleccion_recorrida) {
    // pintar productos. bucle que recorre el catalogo y en cada vuelta muestra un producto
    //  ___________________________________________________
    area.innerHTML = ""
    let fila;
    copiacoleccion_recorrida = coleccion_recorrida
    coleccion_recorrida.forEach((producto, index) => {
        // Crear una nueva fila cada 3 productos
        if (index % 3 === 0) {
            fila = document.createElement('div');
            fila.classList.add('row', 'mb-4'); // margen inferior
            area.appendChild(fila);
        }
        imagendestacado = ""
        // Crear una tarjeta dentro de una columna
        if (producto.destacado == true) {
            imagendestacado = "destacado_si.png"
        } else {
            imagendestacado = "destacado_no.png"
        }
        const columna = document.createElement('div');
        columna.classList.add('col-md-4'); // Cada tarjeta ocupa 1/3 del ancho
        var identificadordecadaproducto = "imgdestacada," + producto.idProducto
        columna.innerHTML = `
            <div class="card">
                <div class="card-body bg-light">
                    <h5 class="card-title">${producto.nombre}</h5>
                    <img src="./assets/${imagendestacado}" class ="imgdestacada"  id ="${identificadordecadaproducto}">
                    <img src="./assets/${producto.imagen}"  class=" img-fluid max-width: 100%;  height: auto; " >
                    <p class="card-text text-secondary"><strong>${producto.precio.toFixed(2)}</strong></p>
                    <a href="pagina_producto.html?idProducto=${producto.idProducto}" class="btn bg-white text-secondary">Consultar producto</a>
                    </div>
                    </div>
                    `;

        // Agregar la tarjeta a la fila actual
        fila.appendChild(columna);


        document.getElementById(identificadordecadaproducto).addEventListener("click", x => {
            //  alert("Pulsado el id" + identificadordecadaproducto)
            trozos = identificadordecadaproducto.split(",")
            idquebuscamos = parseInt(trozos[1])
            // hay que guadar tambien en losvistos recientemente si uno de ellos es destacado o no 
            arrayvistos = leerDeLocalstorage("VISTOS")
            for (unproducto of arrayvistos) {

                if (unproducto.idProducto == idquebuscamos) {
                    // cambiamos el atributo del producto, para que sea destacado o no destacado
                    unproducto.destacado = !unproducto.destacado
                    // guardar el cambio del producto seleccionado en la tienda
                    guardarLocalstorage("VISTOS", arrayvistos)

                }
            }



            for (unproducto of tiendacomoobjeto.productos) {

                if (unproducto.idProducto == idquebuscamos) {
                    // cambiamos el atributo del producto, para que sea destacado o no destacado
                    unproducto.destacado = !unproducto.destacado
                    // cambiamos el icono del producto que acabamos de pinchar
                    if (unproducto.destacado == true) {
                        document.getElementById(identificadordecadaproducto).src = "./assets/destacado_si.png"
                    } else {
                        document.getElementById(identificadordecadaproducto).src = "./assets/destacado_no.png"
                    }
                    // guardar el cambio del producto seleccionado en la tienda
                    guardarLocalstorage("TIENDA", tiendacomoobjeto)


                    if (opcion == "destacados") {
                        coleccion_recorrida = filtrarPorDestacados()
                    }
                    if (opcion == "recientes") {
                        coleccion_recorrida = arrayvistos
                    }
                    pintar(opcion, coleccion_recorrida)
                }
            }




        })


    });
    //  ___________________________________________________


}





function filtrarPorCategoria(categoriabuscada) {
    resultado = []
    for (cadaproducto of tiendacomoobjeto.productos) {
        if (cadaproducto.id_categoria == parseInt(categoriabuscada)) {
            resultado.push(cadaproducto)
        }
    }
    return resultado
}

function filtrarPorDestacados() {
    resultado = []
    for (cadaproducto of tiendacomoobjeto.productos) {
        if (cadaproducto.destacado == true) {
            resultado.push(cadaproducto)
        }
    }
    return resultado
}

// guarda un objeto en localstorage, pero ha de ser un STRING, 
// convertir un objeto en string con JSON.stringify( objeto ) 
function guardarLocalstorage(nombre, unobjeto) {
    cadena = JSON.stringify(unobjeto)
    localStorage.setItem(nombre, cadena)
}


// devuelve el contenido de localstotage como un STRING, 
// se convierte un string en un objeto con JSON.parse( stringdado  )
function leerDeLocalstorage(nombre) {
    cadena = localStorage.getItem(nombre)
    return JSON.parse(cadena)
}

async function enviarToken() {

    tokenrecuperadodestorage = leerDeLocalstorage("TOKEN")

    if (!tokenrecuperadodestorage) {
        // el token no existe, ni siquiera se ha pasado antes por login y se ha pedido al servidor, 
        // asi que nos piramos al login.html
        alert("Debe autenticarse para acceder al contenido de la web")
        window.location.href = "pagina_login.html"
    }


    // llegados aqui, es que hay token, 
    // pero necesitamos pedir al servidor que valide la integridad del token que tenemos 

    carpeta_proyecto = "http://localhost/Tienda/"
    const response = await fetch(carpeta_proyecto + 'Carpeta_servidor/responder_si_token_vale.PHP', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${tokenrecuperadodestorage}` },
        // convertirmos el objeo literal a un JSON para enviarlo 
        body: JSON.stringify("")
    });

    // ================ respuesta de servidor  ==============
    if (response.status == 200) {  // es lo mismo que response.ok, es que hemos recibido un codigo de respuesta 200

        // no hacemos nada

    } else {
        // asi que nos piramos al login.html
        window.location.href = "pagina_login.html"
    }

}