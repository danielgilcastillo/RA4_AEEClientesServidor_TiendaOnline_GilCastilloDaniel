
    // ---------- enviar token a servidor y ver si es valido, si no, volvemos a login.html
    enviarToken()
    // CODIGO JAVASCRIPT IGUAL PARA TODAS LAS PAGINAS 
    window.onload = inicio

    // Cargar contenido de cabecera.html
    fetch('componente_cabecera.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('contenedor-cabecera').innerHTML = html;
        })
    // Cargar contenido de cabecera.html
    fetch('componente_pie.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('contenedor-pie').innerHTML = html;
        })



    function inicio() {

        // Obtener los parámetros de la URL
        const queryString = window.location.search;
        // Crear un objeto con los parámetros usando URLSearchParams
        const urlParams = new URLSearchParams(queryString);
        // Leer los valores de los parámetros
        const idrequerido = urlParams.get('idProducto');

        tiendaleidacomostring = leerDeLocalstorage("TIENDA")
        tiendacomoobjeto = JSON.parse(tiendaleidacomostring)

        
        vistoscomostring = leerDeLocalstorage("VISTOS")
        vistoscomoobjeto = JSON.parse(vistoscomostring)

        productoelegido = null
        tiendacomoobjeto.productos.forEach(producto => {
            if (parseInt(producto.idProducto) == idrequerido) {
                productoelegido = producto
            }
        })

        const objetoBuscado = vistoscomoobjeto.find(objeto => objeto.idProducto === productoelegido.idProducto);
        if(objetoBuscado == undefined){
             vistoscomoobjeto.push(productoelegido)
        }
      
        
        
        
        guardarLocalstorage("VISTOS", JSON.stringify(vistoscomoobjeto))

        nombrecagetoria = "Indefinida"

        tiendacomoobjeto.categorias.forEach(cat => {
            if(cat.id_categoria == productoelegido.id_categoria){
                nombrecagetoria = cat.nombre
            }
        })


        textotitulo = `<div class="col-md-12 text-center">
                              <h1>DETALLE DEL PRODUCTO</h1>
                           </div>`
        document.getElementById("titulopagina").innerHTML = textotitulo


        card = `   <div class="card bg-light max-width=50%;" >
            <div class="card-body" >
                <h5 class="card-title">${productoelegido.nombre}</h5>
                      <img src="./assets/${productoelegido.imagen}"  style="width: 40%;   " >
            
                <p class="card-text text-secondary"><strong>ID: ${productoelegido.idProducto}</strong></p>     
                <p class="card-text text-secondary"><strong>Categoria: ${nombrecagetoria}</strong></p>     
                <p class="card-text text-secondary"><strong>Precio: ${productoelegido.precio.toFixed(2)}</strong></p>        
                  <a href="pagina_carrito.html?idProducto=${productoelegido.idProducto}" class="btn bg-white text-secondary">AGREGAR AL CARRITO</a>
            </div>
        </div>`
        document.getElementById("areadecolocaciondeestapagina").innerHTML = card
    }

    function guardarLocalstorage(nombre, algo) {
        localStorage.setItem(nombre, algo)
    }


    function leerDeLocalstorage(nombre) {
        return localStorage.getItem(nombre)
    }

    async function enviarToken(){

        tokenrecuperadodestorage = leerDeLocalstorage("TOKEN")
  
         if( ! tokenrecuperadodestorage ){
            // el token no existe, ni siquiera se ha pasado antes por login y se ha pedido al servidor, 
            // asi que nos piramos al login.html
            alert("Debe autenticarse para acceder al contenido de la web")
            window.location.href  ="pagina_login.html"
         } 

    
         // llegados aqui, es que hay token, 
         // pero necesitamos pedir al servidor que valide la integridad del token que tenemos 

         carpeta_proyecto = "http://localhost/Tienda/"
         const response = await fetch(carpeta_proyecto + 'Carpeta_servidor/responder_si_token_vale.PHP', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${tokenrecuperadodestorage}` },
            // convertirmos el objeo literal a un JSON para enviarlo 
            body: JSON.stringify("")
        });

        // ================ respuesta de servidor  ==============
        if (response.status == 200) {  // es lo mismo que response.ok, es que hemos recibido un codigo de respuesta 200

            // el servidor respondio que todo ok, asi que no hacemos nada

        } else {
            // el servidor respondio con algun error,  asi que nos piramos al login.html
            window.location.href  ="pagina_login.html"
        }

    }