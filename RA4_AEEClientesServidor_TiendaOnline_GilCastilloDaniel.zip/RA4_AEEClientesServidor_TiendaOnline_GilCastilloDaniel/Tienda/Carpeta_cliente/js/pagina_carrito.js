
// ---------- enviar token a servidor y ver si es valido, si no, volvemos a login.html
enviarToken()

// CODIGO JAVASCRIPT IGUAL PARA TODAS LAS PAGINAS 
window.onload = inicio

// Cargar contenido de cabecera.html
fetch('componente_cabecera.html')
    .then(response => response.text())
    .then(html => {
        
        document.getElementById('contenedor-cabecera').innerHTML = html;
    })
// Cargar contenido de cabecera.html
fetch('componente_pie.html')
    .then(response => response.text())
    .then(html => {
        document.getElementById('contenedor-pie').innerHTML = html;
    })
areadecolocaciondeestapagina = document.getElementById("areadecolocaciondeestapagina")
carpeta_proyecto = "http://localhost/Tienda/"

// CODIGO JAVASCRIPT DE ESTA PAGINA 

function inicio() {

    // Obtener los parámetros de la URL
    const queryString = window.location.search;
    // Crear un objeto con los parámetros usando URLSearchParams
    const urlParams = new URLSearchParams(queryString);
    // Leer los valores de los parámetros
    const idrequerido = urlParams.get('idProducto');

    tiendacomoobjeto = leerDeLocalstorage("TIENDA")
    arraycarrito = leerDeLocalstorage("CARRITO")

    // metemos un producto al carrto, si en la url venia el valor idproducto
    if (idrequerido != null) {
        productoelegido = null
        tiendacomoobjeto.productos.forEach(producto => {
            if (parseInt(producto.idProducto) == idrequerido) {
                productoelegido = producto
            }
        })

        // no metemos directamente el producto en el carrito,
        // vemos si estaba ya antes y en tal caso incrementamos su cantidad,
        // y si no, la dejamos a 1
        var encontrado = false
        arraycarrito.forEach(producto => {
            if (parseInt(producto.idProducto) == productoelegido.idProducto) {
                producto.cantidadpedida++
                encontrado = true
            }
        })
        if (encontrado == false) {
            productoelegido.cantidadpedida++
            arraycarrito.push(productoelegido)
        }

        //  arraycarrito.push(productoelegido)

        // guardar nuevamente el carrito en localstorage
        guardarLocalstorage("CARRITO", arraycarrito)
    }


    pintarCarrito()

}

function pintarCarrito() {

    areadecolocaciondeestapagina.innerHTML = ""

    // PINTAMOS TODO
    textotitulo = `<div class="col-md-12 text-center">
                         <h1>CONTENIDO DE TU CARRITO</h1>
                    </div>`
    document.getElementById("titulopagina").innerHTML = textotitulo

    //  ___________________________________________________
    let fila;
    arraycarrito.forEach((producto, index) => {
        // Crear una nueva fila cada 3 productos
        if (index % 1 === 0) {
            fila = document.createElement('div');
            fila.classList.add('row', 'mb-4'); // margen inferior
            areadecolocaciondeestapagina.appendChild(fila);
        }

        // Crear una tarjeta dentro de una columna
        const columna = document.createElement('div');
        columna.classList.add('col-md-6'); // Cada tarjeta ocupa 1/3 del ancho
        var valordelbotonmasconid = "botonmas-" + producto.idProducto
        var valordelbotonmenosconid = "botonmenos-" + producto.idProducto

        columna.innerHTML = `

                <div class="card">
                <div class="card-body">
                <h5 class="card-title">${producto.nombre}</h5>
                <img src="./assets/${producto.imagen}"  class=" img-fluid max-width: 100%;  height: auto; img-thumbnail" >

                <p class="card-text text-black center"><strong>${producto.cantidadpedida} x ${producto.precio.toFixed(2)}</strong></p>
                <div id="${valordelbotonmasconid}"   class="btn bg-black text-white">+</div>
                <div id="${valordelbotonmenosconid}" class="btn bg-black text-white">-</div>
                </div>

                </div>`;


        fila.appendChild(columna);

        document.getElementById(valordelbotonmasconid).addEventListener("click", maspulsado)
        document.getElementById(valordelbotonmenosconid).addEventListener("click", menospulsado)


        if (index == 0) {
            //es la primera fila, pongo el resumen en una nueva columna
            // Crear una tarjeta dentro de una columna
            const columna = document.createElement('div');
            columna.classList.add('col-md-6'); // Cada tarjeta ocupa 1/2 del ancho
            contenidoResumen = pintarResumen()
            contenidoPagoTarjeta = pintarPagoTarjeta()
            cont = `
                        <div class="card">
                            <div class="card-body">
                            ${contenidoResumen}
                            </div>

                            </div>

                            <div class="card" id="divdepago" style="visibility: hidden">
                            <div class="card-body">
                            ${contenidoPagoTarjeta}
                            </div>

                        </div>`;

            columna.innerHTML = cont

            // Agregar la tarjeta a la fila actual
            fila.appendChild(columna);

        }
        areadecolocaciondeestapagina.appendChild(fila);
    });

   

    //  FILA DEL BOTON PAGAR___________________________________________________
    // fila = document.createElement('div');
    // fila.appendChild(columna);
    // areadecolocaciondeestapagina.appendChild(fila);

    // boton pagar, que hace visible el card de tarjeta de pago
    document.getElementById("botonCarrito").addEventListener("click", async (evento) => {
        document.getElementById("divdepago").style.visibility = "visible";
    });


    // ENVIO DE CARRITO a pago final
    document.getElementById("botonPagoFinal").addEventListener("click", async (evento) => {
        // validar que los datos de la tarjeta son correctos
        contenidotarjeta = document.getElementById("pagotarjeta").value       
        contenidomes = document.getElementById("pagomes").value       
        contenidoano = document.getElementById("pagoano").value       
        contenidocvv = document.getElementById("pagocvv").value       
        

        if(contenidotarjeta.trim()=="" || contenidomes.trim()=="" ||contenidoano.trim()=="" ||contenidocvv.trim()==""  ){
            alert("Debe indicar todos los datos de la tarjeta")
            return
        }

       // contenidotarjeta = parseInt(contenidotarjeta)
        contenidomes= parseInt(contenidomes)
        contenidoano = parseInt(contenidoano)
       // contenidocvv = parseInt(contenidocvv)
        
        if(contenidotarjeta.length != 16 ){
            alert("Debe indicar 16 digitos en el numero de la tarjeta")
            return
        }  
        
        if(contenidomes < 1 || contenidomes>12 ){
            alert("Debe indicar un numero de mes correcto")
            return
        } 

        const anoactual = (new Date).getFullYear();
        
        if(contenidoano < anoactual  ){
            alert("Debe indicar un numero de anualidad correcto")
            return
        } 
        
        
        if(contenidocvv.length != 3  ){
            alert("Debe indicar 3 digitos para el CVV")
            return
        } 
        
        
        
        // recuperar token   
        tokenrecuperadodestorage = localStorage.getItem('TOKEN');
        // Elimina las comillas al principio y al final
        tokenrecuperadodestorage = tokenrecuperadodestorage.replace(/^"(.*)"$/, '$1');

        const response = await fetch(carpeta_proyecto + 'Carpeta_servidor/pagar_carrito.PHP', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${tokenrecuperadodestorage}` },
            // convertirmos el objeo literal a un JSON para enviarlo 
            body: JSON.stringify(arraycarrito)
        });

        // ================ respuesta de servidor  ==============
        if (response.ok) {

            // leemos la respuesta de PHP, que es un OBJETO; 
            // ha de convertirse en JSON
            const resultado = await response.json();
            json = JSON.stringify(resultado)
            if (resultado['exito'] == true) {
                alert(resultado['respuesta'])
                reiniciar()
               // document.getElementById("mensajes").innerHTML = resultado['respuesta']
               // document.getElementById("botonCarrito").innerHTML = 'VOLVER'
              //  document.getElementById("botonCarrito").addEventListener("click", reiniciar)
            } else {
                alert(resultado['respuesta'])
                //   document.getElementById("mensajes").innerHTML = resultado['respuesta']
                window.location.href = "pagina_desconexion.html"
            }
            document.getElementById("divdepago").style.visibility = "hidden";
        } else {
            console.error('Error al procesar la solicitud:', response.statusText);
        }

    });

}

function maspulsado(evento) {
    idpulsado = evento.target.id
    trozos = idpulsado.split("-")
    idbuscado = parseInt(trozos[1])

    arraycarrito.forEach((producto, index) => {
        if (producto.idProducto == idbuscado) {
            producto.cantidadpedida++
            guardarLocalstorage("CARRITO", arraycarrito)
            pintarCarrito()
        }
    })
}

function menospulsado(evento) {
    idpulsado = evento.target.id
    trozos = idpulsado.split("-")
    idbuscado = parseInt(trozos[1])

    arraycarrito.forEach((producto, index) => {
        if (producto.idProducto == idbuscado) {
            if (producto.cantidadpedida > 0) {
                producto.cantidadpedida--
                guardarLocalstorage("CARRITO", arraycarrito)
                pintarCarrito()
            }
        }
    })
}

function pintarResumen() {

    contenido = '<table>'
    // cabeceras
    contenido += '<tr>'
    contenido += '<th>'
    contenido += 'PRODUCTO'
    contenido += '</th>'

    contenido += '<th>'
    contenido += 'CANTIDAD'
    contenido += '</th>'

    contenido += '<th>'
    contenido += 'PRECIO FINAL'
    contenido += '</th>'
    contenido += '</tr>'


    totalfinal = 0
    arraycarrito.forEach(producto => {
        if (producto.cantidadpedida > 0) {
            contenido += '<tr>'

            total = producto.cantidadpedida * producto.precio
            contenido += '<td>'
            contenido += producto.nombre
            contenido += '</td>'

            contenido += '<td>'
            contenido += producto.cantidadpedida
            contenido += '</td>'

            contenido += '<td>'
            contenido += total.toFixed(2)
            contenido += '</td>'

            contenido += '</tr>'
            totalfinal += total
        }
    })


    contenido += '<tr>'
    contenido += '<td>'
    contenido += `<br>TOTAL FINAL: ` + totalfinal.toFixed(2)
    contenido += '</td>'
    contenido += '</tr>'

    contenido += '</table>'



    contenido += `<div class="container-fluid text-center">
                       <div id="botonCarrito" class="btn bg-secondary text-white">PAGAR</div>
                     </div>   `

    return contenido
}


function pintarPagoTarjeta() {

    contenido = '<p>NUMERO DE TARJETA<p>'
    contenido += '<input type="number" id="pagotarjeta" maxlength="16" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">'

    contenido += '<p>CADUCIDAD (MES/ANUALIDAD) <p>'
    contenido += '<input type="number" id="pagomes"  maxlength="2" min="0" max="99" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">'
    contenido += '<input type="number" id="pagoano"  maxlength="4" min="0" max="9999" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">'

    contenido += '<p>CVV<p>'
    contenido += '<input type="number" id="pagocvv"  maxlength="3" min="0" max="999" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">'
    contenido += ' <span id="botonPagoFinal" class="btn bg-secondary text-white">ENVIAR PAGO</span>'
    return contenido

}










// guarda un objeto en localstorage, pero ha de ser un STRING, 
// convertir un objeto en string con JSON.stringify( objeto ) 
function guardarLocalstorage(nombre, unobjeto) {
    cadena = JSON.stringify(unobjeto),
        localStorage.setItem(nombre, cadena)
}


// devuelve el contenido de localstotage como un STRING, 
// se convierte un string en un objeto con JSON.parse( stringdado  )
function leerDeLocalstorage(nombre) {
    return JSON.parse(localStorage.getItem(nombre))
}

function reiniciar() {
    arraycarrito = []
    // guardar nuevamente el carrito en localstorage
    guardarLocalstorage("CARRITO", arraycarrito)
    window.location.href = 'pagina_catalogo.html?opcion=todos';
}

async function enviarToken() {

    tokenrecuperadodestorage = leerDeLocalstorage("TOKEN")

    if (!tokenrecuperadodestorage) {
        // el token no existe, ni siquiera se ha pasado antes por login y se ha pedido al servidor, 
        // asi que nos piramos al login.html
        alert("Debe autenticarse para acceder al contenido de la web")
        window.location.href = "pagina_login.html"
    }


    // llegados aqui, es que hay token, 
    // pero necesitamos pedir al servidor que valide la integridad del token que tenemos 

    carpeta_proyecto = "http://localhost/Tienda/"
    const response = await fetch(carpeta_proyecto + 'Carpeta_servidor/responder_si_token_vale.PHP', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${tokenrecuperadodestorage}` },
        // convertirmos el objeo literal a un JSON para enviarlo 
        body: JSON.stringify("")
    });

    // ================ respuesta de servidor  ==============
    if (response.status == 200) {  // es lo mismo que response.ok, es que hemos recibido un codigo de respuesta 200

        // no hacemos nada

    } else {
        // asi que nos piramos al login.html
        window.location.href = "pagina_login.html"
    }

}