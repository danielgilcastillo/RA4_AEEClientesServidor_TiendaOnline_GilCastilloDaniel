
    // CODIGO JAVASCRIPT IGUAL PARA TODAS LAS PAGINAS 
   
       // ---------- enviar token a servidor y ver si es valido, si no, volvemos a login.html
       enviarToken()

   
    window.onload = inicio

    // Cargar contenido de cabecera.html
    fetch('componente_cabecera.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('contenedor-cabecera').innerHTML = html;
        })
    // Cargar contenido de cabecera.html
    fetch('componente_pie.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('contenedor-pie').innerHTML = html;
        })



    function inicio() {

        tiendacomoobjeto = leerDeLocalstorage("TIENDA")

        textotitulo = `<div class="col-md-12 text-center text-secondary">
                              <h1>CATEGORIAS</h1>
                           </div>`
        document.getElementById("titulopagina").innerHTML = textotitulo

        // pintar categoraias
        area = document.getElementById("areadecolocaciondeestapagina")
        let fila;
        tiendacomoobjeto.categorias.forEach((categoria, index) => {
            // Crear una nueva fila cada 3 productos
            if (index % 3 === 0) {
                fila = document.createElement('div');
                fila.classList.add('row', 'mb-4'); // margen inferior
                area.appendChild(fila);
            }

            // Crear una tarjeta dentro de una columna
            const columna = document.createElement('div');
            columna.classList.add('col-md-4'); // Cada tarjeta ocupa 1/3 del ancho
            columna.innerHTML = `
            <div class="card bg-light">
                <div class="card-body">
                            <a href="pagina_catalogo.html?categoria=${categoria.idCategoria}" class="btn bg-white text-secondary">${categoria.nombre}</a>
                 
                    </div>
                    </div>
                    `;

            // Agregar la tarjeta a la fila actual
            fila.appendChild(columna);
        });
        //  ___________________________________________________
       

    }
    // guarda un objeto en localstorage, pero ha de ser un STRING, 
    // convertir un objeto en string con JSON.stringify( objeto ) 
    function guardarLocalstorage(nombre, unobjeto) {
        cadena = JSON.stringify(unobjeto)
        localStorage.setItem(nombre, cadena)
    }


    // devuelve el contenido de localstotage como un STRING, 
    // se convierte un string en un objeto con JSON.parse( stringdado  )
    function leerDeLocalstorage(nombre) {
        cadena = localStorage.getItem(nombre)
        if(cadena==''){
            return null
        }
        return JSON.parse(cadena)
    }

    async function enviarToken(){

        tokenrecuperadodestorage = leerDeLocalstorage("TOKEN")
  
         if( ! tokenrecuperadodestorage ){
            // el token no existe, ni siquiera se ha pasado antes por login y se ha pedido al servidor, 
            // asi que nos piramos al login.html
            alert("Debe autenticarse para acceder al contenido de la web")
            window.location.href  ="pagina_login.html"
         } 

    
         // llegados aqui, es que hay token, 
         // pero necesitamos pedir al servidor que valide la integridad del token que tenemos 

         carpeta_proyecto = "http://localhost/Tienda/"
         const response = await fetch(carpeta_proyecto + 'Carpeta_servidor/responder_si_token_vale.PHP', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${tokenrecuperadodestorage}` },
            // convertirmos el objeo literal a un JSON para enviarlo 
            body: JSON.stringify("")
        });

        // ================ respuesta de servidor  ==============
        if (response.status == 200) {  // es lo mismo que response.ok, es que hemos recibido un codigo de respuesta 200

            // no hacemos nada

        } else {
            // asi que nos piramos al login.html
            window.location.href  ="pagina_login.html"
        }

    }
    